require 'test_helper'

class ZawodniksControllerTest < ActionDispatch::IntegrationTest
  setup do
    @zawodnik = zawodniks(:one)
  end

  test "should get index" do
    get zawodniks_url
    assert_response :success
  end

  test "should get new" do
    get new_zawodnik_url
    assert_response :success
  end

  test "should create zawodnik" do
    assert_difference('Zawodnik.count') do
      post zawodniks_url, params: { zawodnik: { Adres: @zawodnik.Adres, Imie: @zawodnik.Imie, Nazwisko: @zawodnik.Nazwisko, PESEL: @zawodnik.PESEL, Status: @zawodnik.Status, Telefon: @zawodnik.Telefon } }
    end

    assert_redirected_to zawodnik_url(Zawodnik.last)
  end

  test "should show zawodnik" do
    get zawodnik_url(@zawodnik)
    assert_response :success
  end

  test "should get edit" do
    get edit_zawodnik_url(@zawodnik)
    assert_response :success
  end

  test "should update zawodnik" do
    patch zawodnik_url(@zawodnik), params: { zawodnik: { Adres: @zawodnik.Adres, Imie: @zawodnik.Imie, Nazwisko: @zawodnik.Nazwisko, PESEL: @zawodnik.PESEL, Status: @zawodnik.Status, Telefon: @zawodnik.Telefon } }
    assert_redirected_to zawodnik_url(@zawodnik)
  end

  test "should destroy zawodnik" do
    assert_difference('Zawodnik.count', -1) do
      delete zawodnik_url(@zawodnik)
    end

    assert_redirected_to zawodniks_url
  end
end
